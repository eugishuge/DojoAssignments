from django.shortcuts import render, redirect
from ..login.models import User
from .models import Travel, Join
from django.contrib import messages

# Create your views here.
def travels(request):
    all_plans = Join.objects.all().exclude(all_users__username=request.session['username'])
    plans = Travel.objects.all()

    join = Join.objects.all()

    user_travel = Join.objects.filter(all_users__username=request.session['username'])

    all_travels = Join.objects.filter()

    context = {
    'plans' : plans,
    'join': join,
    'user_travel': user_travel,
    'all_plans': all_plans
    }
    return render(request, "blackbelt_templates/travels.html", context)

def join_travel(request,_id):
    join_travel = Travel.objects.filter(id = _id)
    join_user = User.objects.filter(username = request.session['username'])

    Join.objects.create(all_travel = join_travel[0], all_users = join_user[0])

    return redirect('/blackbelt/travels')

def trip_details(request,_id):
    trip = Travel.objects.filter(id = _id)
    user = User.objects.filter(username = request.session['username'])
    context={
    'trip': trip,
    'user': user
    }
    return render(request, "blackbelt_templates/details.html",context)

def go_add(request):
    return render(request, "blackbelt_templates/add.html")

def add(request):
    _add = Travel.objects.add(request.POST)


    user_travel = User.objects.filter(username = request.session['username'])

    if _add == True:
        Join.objects.create(all_users = user_travel[0], all_travel = Travel.objects.latest('id'))
        return redirect('/blackbelt/travels')
    else:
        for x in _add[1]:
            messages.error(request, x)
        return redirect('/blackbelt/go_add')

def logout(request):
    request.session.clear()
    return redirect('/')

def delete(request, _id):
    Travel.objects.filter(id=_id).delete()
    return redirect('/blackbelt/travels')
