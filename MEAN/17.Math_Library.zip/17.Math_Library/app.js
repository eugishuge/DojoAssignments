var eug_module = require('./mathlib')();
// console.log(eug_module.add(5,6));
// console.log(eug_module.multiply(5,6));
// console.log(eug_module.square(5));
console.log(eug_module.random(10,10));
